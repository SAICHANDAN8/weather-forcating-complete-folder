from django.contrib import admin
from .models import userModel
# Register your models here.
admin.site.register(userModel)